<footer class="ftco-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="ftco-footer-widget mb-4">
                    <h2 class="ftco-heading-2">Alamat</h2>
                    <div class="block-23 mb-3">
                        <ul>
                            <li><span class="icon fa fa-map marker"></span><span class="text">MHVW+4JX, Sun Plaza Lt.3, Jl. Imam Bonjol, Kec. Medan Kota, Kota Medan, Sumatera Utara 20245</span></li>

                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="ftco-footer-widget mb-4">
                    <h2 class="ftco-heading-2">Kontak</h2>
                    <div class="block-23 mb-3">
                        <ul>
                            <li><span class="icon fa fa-whatsapp"></span><span class="text">0812-3456-7890</span></li>
                            <li><span class="icon fa fa-phone"></span><span class="text">0812-3456-7890</span></li>
                            <li><span class="icon fa fa-instagram"></span><span class="text">Yudimsum</span></li>

                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="ftco-footer-widget mb-4">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3982.02354241306!2d98.66879627365665!3d3.582066750341669!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x303131cd6e10abb5%3A0xf4a6500e549d1a82!2sSun%20Plaza!5e0!3m2!1sen!2sid!4v1688559180661!5m2!1sen!2sid" width="400" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- loader -->
<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
        <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
        <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00" />
    </svg></div>


<script src="home/js/jquery.min.js"></script>
<script src="home/js/jquery-migrate-3.0.1.min.js"></script>
<script src="home/js/popper.min.js"></script>
<script src="home/js/bootstrap.min.js"></script>
<script src="home/js/jquery.easing.1.3.js"></script>
<script src="home/js/jquery.waypoints.min.js"></script>
<script src="home/js/jquery.stellar.min.js"></script>
<script src="home/js/owl.carousel.min.js"></script>
<script src="home/js/jquery.magnific-popup.min.js"></script>
<script src="home/js/jquery.animateNumber.min.js"></script>
<script src="home/js/scrollax.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
<script src="home/js/google-map.js"></script>
<script src="home/js/main.js"></script>

</body>

</html>